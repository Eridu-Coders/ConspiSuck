# Meme OCR

This is an optical character recognition (OCR) tool using [Tesseract][1] specifically for internet meme images.

A dedicated trained Tesseract model is included.


[1]: https://code.google.com/p/tesseract-ocr/
